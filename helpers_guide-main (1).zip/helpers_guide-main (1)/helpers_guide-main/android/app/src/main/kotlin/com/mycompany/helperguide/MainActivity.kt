package com.mycompany.helperguide

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
